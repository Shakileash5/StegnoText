var ad = document.getElementById("adv1")
ad.addEventListener("click", () => {
    document.getElementById('option').classList.toggle("trans")
})